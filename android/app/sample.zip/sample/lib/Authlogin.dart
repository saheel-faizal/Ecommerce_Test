import 'package:flutter/material.dart';

class Loginauth extends StatefulWidget {
  @override
  _LoginauthState createState() => _LoginauthState();
}

class _LoginauthState extends State<Loginauth> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(),
    );
  }
}
