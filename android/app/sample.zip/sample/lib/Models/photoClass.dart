class photoClass{
  int albimId;
  int id;
  String title;
  String url;
  String thumbnailUrl;
  photoClass(this.albimId,this.id,this.title,this.url,this.thumbnailUrl);
}