class multipleData{
  int userId;
  int id;
  String title;
  String body;
  multipleData(this.userId,this.id,this.title,this.body);

  // factory multipleData.fromjson(Map<String,dynamic> json){
  //   return multipleData(
  //     userId: json["userId"],
  //     id: json["id"],
  //     title: json["title"],
  //     body: json["body"]
  //
  //   );

 // }

}