class brandArray {
  String company;
  String description;
  String employementType;
  int id;
  String location;
  String position;

  brandArray(this.company,this.description,this.employementType,this.id,this.location,this.position);
}